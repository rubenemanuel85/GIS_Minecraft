#This part of the script loads the libraries the script uses in order to build the world. 
import os
import sys
from PIL import Image
from pymclevel import mclevel, box
from pymclevel.materials import alphaMaterials as m

# Here you can define the location where your generated world will be saved. 
# Change the path name so it saves it in your folder
minecraft_save_dir = "D:/VRS/OneDrive - Van Hall Larenstein/MSc/Thesis/Mine_GBR_world/"

# Map_type 1 stands for creative mode
map_type = 1

# Here you define the prefix of the file names for your data and the name of your World. 
# Since you saved the data as 'VU_elevation.png' and 'VU_features.png' the prefix is in this case 'VU'
filename_prefix = "GBR"

# Here you define what BlockID corresponds with what block type.
# In your case Roads (1) --> Grey Wool, Water (2) --> Water, Buildings (3) --> Bricks and Grass (4)--> Grass 
# Some of the block types have a number behind its ID string, this number corresponds with one variety of that block type.
# White Wool for examples comes in several colours, each color has its own number. The 7 stands for the variety Grey Wool, 0 stands for White Wool, 1 for Orange, etc..
# Some block types have no variety and instead of a number it uses None.
# You can change these block types by changing the piece of code to the corresponding code of the block type you wish to have
# You can find the different block types in minecraft.yaml which is located in the pymclevel folder.
block_id_lookup = {
    
    1  : (m.WhiteWool.ID, 15),  #isoline
    2  : (m.WhiteWool.ID, 7),   #isoline
    3  : (m.WhiteWool.ID, 11),  #isoline
    4  : (m.WhiteWool.ID, 3),   #isoline
    5  : (m.Clay.ID, None),     #isoline
    6  : (m.WhiteWool.ID, 8),   #isoline
    7  : (m.WhiteWool.ID, 0),   #isoline
    8  : (m.Sand.ID, 0),        #isoline
    9  : (m.Grass.ID, None),     #isoline
    10  : (m.Grass.ID, None),    #isoline
    11  : (m.Grass.ID, None),    #isoline
    12  : (m.Grass.ID, None),    #isoline
    13  : (m.Grass.ID, None),    #isoline
    14  : (m.Grass.ID, None),    #isoline
    15  : (m.Grass.ID, None),    #isoline
    16  : (m.Grass.ID, None),    #isoline
    17  : (m.Grass.ID, None),    #isoline
    18  : (m.Grass.ID, None),    #isoline
    19  : (m.Grass.ID, None),    #isoline
    20 : (m.Dirt.ID, None),     #mainland
    21 : (m.Dirt.ID, None),     #islands
    22 : (m.Clay.ID, None),     #rock features
    23 : (m.WhiteWool.ID, 3),   #cay areas
    24 : (m.WhiteWool.ID, 0),   #reefs
    50  : (m.WhiteWool.ID, 0),  #outer border
    60  : (m.Glass.ID, None),   #outer wall
    100  : (m.WhiteWool.ID, 6), #gridlines
    200 : (m.WhiteWool.ID, 4),  #centre / orientation pole/s
    }


# Here the data you prepared is loaded by the script and a table is created with all the necessary parameters in order to build the world.
# With the print function you can show messages while running the script. With these messages track the progression of the script while it's running.
print "Loading data for %s" % filename_prefix
data = dict(elevation=[], features=[])
for t in 'elevation', 'features':
    filename = filename_prefix + "_" + t + ".png"
    if not os.path.exists(filename):
        print "Could not load image file %s!" % filename
        sys.exit()
    img = Image.open(filename, "r")
    width, height = img.size
    for i in range(max(width, 0)):
        row = []
        for j in range(max(height, 0)):
            pixel = img.getpixel((i,j))
            value = pixel[0]
            if t == 'features':
                value = (value, pixel[1]) # block ID, block data
            if t == 'elevation':
                elevation_min = min(value, 0)
                elevation_max = max(value, 255)
            row.append(value)
        data[t].append(row)

elevation = data['elevation']
material = data['features']

# The len(...) function shows the length of the list, it tells the amount of columns or rows 
print "Map is %s high, %s wide" % (len(elevation), len(elevation[0]))

# The following piece of the script creates the world file in the location you have given at the start

i = 0
worlddir = None
while not worlddir or os.path.exists(worlddir):
    i += 1
    name = filename_prefix + " map " + str(i)
    worlddir = os.path.join(minecraft_save_dir, name)

print "Creating world %s" % worlddir
world = mclevel.MCInfdevOldLevel(worlddir, create=True)
from pymclevel.nbt import TAG_Int, TAG_String, TAG_Byte_Array
tags = [TAG_Int(0, "MapFeatures"),
        TAG_String("flat", "generatorName"),
        TAG_String("0", "generatorOptions")]
for tag in tags:
    world.root_tag['Data'].add(tag)

peak = [1, 255, 1]

print "Creating Chunks."

# Before filling in your blocks the script first creates an empty world full of air.
# With the len(...) function from before the script calculates how big the world will be.
# By using the box.BoundingBox(...) function it creates a selection of where the blocks will be placed.
# world.createChunksInBox(...) creates the chunks, chunks are segments of the world and are 16 blocks wide, 16 blocks long and 256 blocks deep.
# When you enter and move through the world chunks are used to load the world around you. Depending on the settings you can tell the game how many chunks it can load at the same time.
# Finally the script fills the created boundingbox with air by using the world.fillBlocks(...).

x_extent = len(elevation)
x_extension = 2986 #height of the map / GIS columns of rasterdata - border*2
z_extent = len(elevation[0])
z_extension = 2778 #width of the map / GIS rows of rasterdata - border*2 -1
air_bottom_left = (0,0,0) #border, z+1
air_upper_right = [x_extent, 60, z_extent]
airbox = box.BoundingBox(air_bottom_left, air_upper_right)
chunks = world.createChunksInBox(airbox)
world.fillBlocks(airbox, m.Water)

# Now the script will use your data to create the world.
# It goes through the created list by using loops and uses the world.setBlockAt(...) command to place them.
# The script builds the world from the bottom up, it starts placing blocks from 1 meter and keeps placing blocks till the height given by the elevation raster.
# One limitation of the script therefor is that it can't create holes through buildings or create bridges. 
# This can be done with the same library used here but with a different method which is a little bit more complicated and requires 3d modelling with for example CityEngine. 
  
print "Creating World."
for x, row in enumerate(elevation):
    for z, y in enumerate(row):
        block_id, ignore = material[x][z]

        block_id, block_data, = block_id_lookup[block_id]
        actual_y = y + 1
        if actual_y > peak[1] or (peak[1] == 255 and y != 0):
            peak = [x,actual_y,z]

        start_at = 1
        stop_at = actual_y + 1
        
        for elev in range(start_at, stop_at):
            world.setBlockAt(x, elev, z, block_id)
            if block_data:
                world.setBlockDataAt(x, elev, z, block_data)

# This little piece of code creates a layer of bedrock at the bottom of the map so you won'
# fall through the map if you decide to take a swim.

bottom_left = [-1, 0, -1]
upper_right = [x_extent + 1, 1, z_extent + 1]
tilebox = box.BoundingBox(bottom_left, upper_right)
world.fillBlocks(tilebox, m.Bedrock)

# To finish it off this part of the script creates the spawn point where your character will spawn inside the world and saves the created chunks in the world.

def setspawnandsave(world, point):
    world.GameType = 1
    spawn = point
    spawn[1] += 1
    world.setPlayerPosition(tuple(point))
    world.setPlayerSpawnPosition(tuple(spawn))
    biome = 0
    numchunks = 0
    biomes = TAG_Byte_Array([biome] * 256, "Biomes")
    for i, cPos in enumerate(world.allChunks, 1):
        ch = world.getChunk(*cPos)
        if ch.root_tag:
            ch.root_tag['Level'].add(biomes)
        numchunks += 1

    world.saveInPlace()
    print "Saved %d chunks." % numchunks
    print "Spawning at %r" %spawn

# Here you define the spawn point [ x, z, y]
spawnpoint = [8,100,1346] #mainland     
setspawnandsave(world, spawnpoint)