
FaceXIncreasing = 0
FaceXDecreasing = 1
FaceYIncreasing = 2
FaceYDecreasing = 3
FaceZIncreasing = 4
FaceZDecreasing = 5
MaxDirections = 6

faceDirections = (
                            (FaceXIncreasing, (1, 0, 0)),
                            (FaceXDecreasing, (-1, 0, 0)),
                            (FaceYIncreasing, (0, 1, 0)),
                            (FaceYDecreasing, (0, -1, 0)),
                            (FaceZIncreasing, (0, 0, 1)),
                            (FaceZDecreasing, (0, 0, -1))
                            )
